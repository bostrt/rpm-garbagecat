/**********************************************************************************************************************
 * garbagecat                                                                                                         *
 *                                                                                                                    *
 * Copyright (c) 2008-2020 Mike Millson                                                                               *
 *                                                                                                                    * 
 * All rights reserved. This program and the accompanying materials are made available under the terms of the Eclipse *
 * Public License v1.0 which accompanies this distribution, and is available at                                       *
 * http://www.eclipse.org/legal/epl-v10.html.                                                                         *
 *                                                                                                                    *
 * Contributors:                                                                                                      *
 *    Mike Millson - initial API and implementation                                                                   *
 *********************************************************************************************************************/
package org.eclipselabs.garbagecat.domain.jdk;

import org.eclipselabs.garbagecat.domain.LogEvent;
import org.eclipselabs.garbagecat.util.jdk.JdkUtil;
import org.junit.Assert;

import junit.framework.TestCase;

/**
 * @author <a href="mailto:mmillson@redhat.com">Mike Millson</a>
 * 
 */
public class TestGcLockerEvent extends TestCase {

    public void testNotBlocking() {
        String logLine = "GC locker: Trying a full collection because scavenge failed";
        Assert.assertFalse(JdkUtil.LogEventType.GC_LOCKER.toString() + " incorrectly indentified as blocking.",
                JdkUtil.isBlocking(JdkUtil.identifyEventType(logLine)));
    }

    public void testReportable() {
        String logLine = "GC locker: Trying a full collection because scavenge failed";
        Assert.assertFalse(JdkUtil.LogEventType.GC_LOCKER.toString() + " incorrectly indentified as reportable.",
                JdkUtil.isReportable(JdkUtil.identifyEventType(logLine)));
    }

    public void testLine() {
        String logLine = "GC locker: Trying a full collection because scavenge failed";
        Assert.assertTrue("Log line not recognized as " + JdkUtil.LogEventType.GC_LOCKER.toString() + ".",
                GcLockerEvent.match(logLine));
        GcLockerEvent event = new GcLockerEvent(logLine);
        Assert.assertEquals("Time stamp not parsed correctly.", 0, event.getTimestamp());
    }

    public void testParseLogLine() {
        String logLine = "GC locker: Trying a full collection because scavenge failed";
        LogEvent event = JdkUtil.parseLogLine(logLine);
        Assert.assertTrue(JdkUtil.LogEventType.GC_LOCKER.toString() + " event not identified.",
                event instanceof GcLockerEvent);
    }

    public void testIdentifyEventType() {
        String logLine = "GC locker: Trying a full collection because scavenge failed";
        Assert.assertTrue(JdkUtil.LogEventType.GC_LOCKER.toString() + " event not identified.",
                JdkUtil.identifyEventType(logLine) == JdkUtil.LogEventType.GC_LOCKER);
    }
}
